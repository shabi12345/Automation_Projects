from selenium import webdriver
import unittest
import time
import pytest
import allure

@allure.story('login user story')
class TestLogin():

    # @classmethod
    @pytest.fixture()
    def test_setup(self):

        # global driver
        driver = webdriver.Chrome("C:/Users/salman.ghafoor/PycharmProjects/Testing/drivers/chromedriver.exe")
        # headless phantom webdriver
        # driver = webdriver.PhantomJS(executable_path=config_prop.phantom_driver)
        driver.implicitly_wait(5)
        driver.maximize_window()
        # driver.get(config_prop.app_url)
        driver.get("http://10.20.30.145/")
        driver.find_element_by_id("inputEmail").clear()
        driver.find_element_by_id("inputEmail").send_keys("Administrator")
        driver.find_element_by_id("inputPassword").clear()
        driver.find_element_by_id("inputPassword").send_keys("Stratton2018@")
        # driver.find_element_by_class_name("form-control form-btn").click()
        driver.find_element_by_xpath('//*[@id="app"]/div/div[2]/form/div[1]/div[3]/div[2]/div[4]/input').click()
        time.sleep(10)
        yield
        driver.close()
        driver.quit()

    # @allure.testcase('login test case')
    def test_loginpy(self, test_setup):
        print("hi")

        # driver = self.driver
        # wb = openpyxl.load_workbook("C:/Users/salman.ghafoor/PycharmProjects/Testing/POC_pytest/TestData/sample.xlsx")
        # ws = wb.active
        # user_name = ""

        # for user_names in ws.iter_rows(min_row=2, max_row=2, min_col=2, max_col=2, values_only=True):
        #     user_name = user_names
        # for passwords in ws.iter_rows(min_row=2, max_row=2, min_col=3, max_col=3, values_only=True):
        #     password = passwords
        # self.driver.find_element_by_id(self.username_field).clear()
        # self.driver.find_element_by_id("inputEmail").send_keys("Administrator")
        # self.driver.find_element_by_id(self.username_field).clear()
        # self.driver.find_element_by_id("inputPassword").send_keys("Stratton2018@")

        # login = LoginPage(driver)
        # login.enter_username("Administrator")
        # login.enter_password("Stratton2018@")
        # login.click_login()
        # time.sleep(5)
        # assert "hello" == "hello"
        # assert "hi" == "hello"


    # @allure.testcase("logout test case")
    # def test_logout(self, test_setup):
    #     # driver = self.driver
    #     login = LoginPage(driver)
    #     login.enter_username("admin")
    #     login.enter_password("admin123")
    #     login.click_login()
    #     home = HomePage(driver)
    #     home.click_welcome()
    #     time.sleep(5)
    #     home.click_logout()
        # assert "logout" == "logout"

    # @classmethod
    # def tearDownClass(cls):
    #     cls.driver.close()
    #     cls.driver.quit()

# to run unittest from cmd without use of -m in command
if __name__ == '__main__':
    unittest.main()
    # unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='C:/Users/salman.ghafoor/PycharmProjects//Testing/POC_project/Tests/Reports'))