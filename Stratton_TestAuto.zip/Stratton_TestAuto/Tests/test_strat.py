from selenium import webdriver
import unittest
import time
from Stratton_TestAuto.PageObjects.loginPage import LoginPage
from Stratton_TestAuto.PageObjects.homePage2 import HomePage
from Stratton_TestAuto.TestData.testData import TestData
from Stratton_TestAuto.TestData.configProperties import ConfigProperties
# import HtmlTestRunner
import pytest
import allure
# import openpyxl

@allure.story('login user story')
class TestLogin():

    # @classmethod
    @pytest.fixture()
    def test_setup(self):
        global driver
        global test_data
        global config_prop
        config_prop = ConfigProperties()
        test_data = TestData()
        driver = webdriver.Chrome(config_prop.chrome_driver)
        # headless phantom webdriver
        # driver = webdriver.PhantomJS(executable_path=config_prop.phantom_driver)
        driver.implicitly_wait(5)
        driver.maximize_window()
        driver.get(config_prop.app_url)
        yield
        driver.close()
        driver.quit()

    # @allure.testcase('login test case')
    def test_loginpy(self, test_setup):
        # driver = self.driver
        # wb = openpyxl.load_workbook("C:/Users/salman.ghafoor/PycharmProjects/Testing/POC_pytest/TestData/sample.xlsx")
        # ws = wb.active
        # user_name = ""
        user_name = test_data.get_username()
        # print(user_name)
        password = test_data.get_password()
        # for user_names in ws.iter_rows(min_row=2, max_row=2, min_col=2, max_col=2, values_only=True):
        #     user_name = user_names
        # for passwords in ws.iter_rows(min_row=2, max_row=2, min_col=3, max_col=3, values_only=True):
        #     password = passwords
        login = LoginPage(driver)
        login.enter_username(user_name)
        login.enter_password(password)
        login.click_login()
        
        time.sleep(5)
        # assert "hello" == "hello"
        # assert "hi" == "hello"


    # @allure.testcase("logout test case")
    # def test_logout(self, test_setup):
    #     # driver = self.driver
    #     login = LoginPage(driver)
    #     login.enter_username("admin")
    #     login.enter_password("admin123")
    #     login.click_login()
    #     home = HomePage(driver)
    #     home.click_welcome()
    #     time.sleep(5)
    #     home.click_logout()
        # assert "logout" == "logout"

    # @classmethod
    # def tearDownClass(cls):
    #     cls.driver.close()
    #     cls.driver.quit()

# to run unittest from cmd without use of -m in command
if __name__ == '__main__':
    unittest.main()
    # unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='C:/Users/salman.ghafoor/PycharmProjects//Testing/POC_project/Tests/Reports'))