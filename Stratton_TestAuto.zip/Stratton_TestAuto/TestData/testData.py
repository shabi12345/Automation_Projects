import openpyxl
from Stratton_TestAuto.TestData.configProperties import ConfigProperties

class TestData:

    def __init__(self):
        global wb
        global ws
        global config_prop
        config_prop = ConfigProperties()
        wb = openpyxl.load_workbook(config_prop.test_data)
        # wb = openpyxl.load_workbook("C:/Users/salman.ghafoor/PycharmProjects/Testing/Stratton_TestAuto/TestData/sample.xlsx")
        ws = wb.active

    def get_username(self):
        for user_names in ws.iter_rows(min_row=2, max_row=2, min_col=2, max_col=2, values_only=True):
            user_name = ''.join(user_names)
        return user_name

    def get_password(self):
        for passwords in ws.iter_rows(min_row=2, max_row=2, min_col=3, max_col=3, values_only=True):
            password = ''.join(passwords)
        return password

    def __del__(self):
        wb.close()