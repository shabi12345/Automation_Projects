
class ConfigProperties:
    app_url = "http://10.20.30.145/"
    test_data = "C:/Users/salman.ghafoor/PycharmProjects/Testing/Stratton_TestAuto/TestData/sample.xlsx"
    # test_data1 = "C:/Users/salman.ghafoor/PycharmProjects/Testing/Stratton_TestAuto/TestData/sample.xlsx"
    chrome_driver = "C:/Users/salman.ghafoor/PycharmProjects/Testing/drivers/chromedriver.exe"
    phantom_driver = "C:/Program Files (x86)/Selenium/Drivers/phantomjs-2.1.1-windows/bin/phantomjs.exe"