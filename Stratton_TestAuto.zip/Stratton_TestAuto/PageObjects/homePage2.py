from selenium.common.exceptions import NoSuchElementException
from POC_project.Locators.locators import Locators

class HomePage:

    def __init__(self, driver):
        self.driver = driver

        self.welcome_label = Locators.welcome_label
        self.logout_link = Locators.logout_link

    def click_welcome(self):
        try:
            self.driver.find_element_by_id(self.welcome_label).click()
        except NoSuchElementException:
            print(self.welcome_label + " is not clickable")

    def click_logout(self):
        try:
            self.driver.find_element_by_id(self.logout_link).click()
        except NoSuchElementException:
            print(self.logout_link + " is not clickable")

