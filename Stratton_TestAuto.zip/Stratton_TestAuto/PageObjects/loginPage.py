from selenium.common.exceptions import NoSuchElementException
from Stratton_TestAuto.Locators.locators import Locators

class LoginPage:

    def __init__(self, driver):
        self.driver = driver

        self.username_field = Locators.username_field_id
        self.password_field = Locators.password_field_id
        self.login_button = Locators.login_button_xpath

    def enter_username(self, username):
        try:
            self.driver.find_element_by_id(self.username_field).clear()
            self.driver.find_element_by_id(self.username_field).send_keys(username)
        except NoSuchElementException:
            print(self.username_field + " is not visible")

    def enter_password(self, password):
        try:
            self.driver.find_element_by_id(self.password_field).clear()
            self.driver.find_element_by_id(self.password_field).send_keys(password)
        except NoSuchElementException:
            print(self.password_field + " is not visible")

    def click_login(self):
        try:
            self.driver.find_element_by_xpath(self.login_button).click()
        except NoSuchElementException:
            print(self.login_button + " is not clickable")

