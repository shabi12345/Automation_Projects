class Locators:

    # Login Page
    username_field_id = "inputEmail"
    password_field_id = "inputPassword"
    login_button_xpath = '//*[@id="app"]/div/div[2]/form/div[1]/div[3]/div[2]/div[4]/input'

    # Home Page
    welcome_label = "welcome"
    logout_link = "Logout"